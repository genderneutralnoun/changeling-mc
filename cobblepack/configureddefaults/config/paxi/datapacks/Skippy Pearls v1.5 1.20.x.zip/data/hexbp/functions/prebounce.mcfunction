#Fail if pearl is not going down
execute store result score @s hexbp.yMot run data get entity @s Motion[1] 1000
execute unless score @s hexbp.yMot matches ..0 run return 0

#Get X and Z Motion's absolute value, add Z to X
execute store result score @s hexbp.xMot run data get entity @s Motion[0] 1000
execute store result score @s hexbp.zMot run data get entity @s Motion[2] 1000
execute if score @s hexbp.xMot matches ..0 run scoreboard players operation @s hexbp.xMot *= .-1 hexbp.xMot
execute if score @s hexbp.zMot matches ..0 run scoreboard players operation @s hexbp.zMot *= .-1 hexbp.xMot
scoreboard players operation @s hexbp.xMot += @s hexbp.zMot

#run if X and Z's sum is more than Y-150 and 150
scoreboard players operation @s hexbp.yMot -= .150 hexbp.xMot
execute if score @s hexbp.xMot matches 150.. if score @s hexbp.xMot >= @s hexbp.yMot run data modify entity @s NoGravity set value 1b
execute if score @s hexbp.xMot matches 150.. if score @s hexbp.xMot >= @s hexbp.yMot at @s run function hexbp:bounce
