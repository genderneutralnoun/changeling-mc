function hexbp:ticko
execute as @e[type=ender_pearl,tag=!hexbp.custom_disable] at @s unless block ~ ~1 ~ water if block ~ ~ ~ water run function hexbp:prebounce
## For Devs: you can add the "hexbp.custom_disable" tag to the pearls that you don't want to bounce