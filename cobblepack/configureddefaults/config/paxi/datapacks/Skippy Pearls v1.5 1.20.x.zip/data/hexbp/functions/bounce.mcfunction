execute at @s run playsound minecraft:entity.generic.splash player @a
data modify entity @s NoGravity set value 0b
execute store result entity @s Motion[1] double -.001 run data get entity @s Motion[1] 1000