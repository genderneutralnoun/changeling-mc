execute as @e[type=origins:enderian_pearl,tag=!hexbp.custom_disable] at @s unless block ~ ~1 ~ water if block ~ ~ ~ water run function hexbp:prebounce
