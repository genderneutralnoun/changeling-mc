scoreboard objectives add hexbp.xMot dummy
scoreboard objectives add hexbp.yMot dummy
scoreboard objectives add hexbp.zMot dummy
scoreboard players set .-1 hexbp.xMot -1
scoreboard players set .150 hexbp.xMot 150